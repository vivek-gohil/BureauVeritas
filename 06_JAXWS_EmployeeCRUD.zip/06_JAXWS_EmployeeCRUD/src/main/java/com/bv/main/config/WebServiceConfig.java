package com.bv.main.config;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bv.main.service.EmployeeCRUDService;

@Configuration
public class WebServiceConfig {

	@Bean
	public Endpoint endpoint(Bus bus) {
		Endpoint endpoint = new EndpointImpl(bus, new EmployeeCRUDService());
		endpoint.publish("/employeecrud");
		return endpoint;
	}
}
