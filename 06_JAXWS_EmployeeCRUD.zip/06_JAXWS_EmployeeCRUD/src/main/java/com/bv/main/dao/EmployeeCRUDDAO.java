package com.bv.main.dao;

import java.util.ArrayList;
import java.util.List;

import com.bv.main.pojo.Employee;

public class EmployeeCRUDDAO implements EmployeeCRUDDAOInterface {

	private List<Employee> employees = new ArrayList<Employee>();

	@Override
	public boolean addNewEmployee(Employee employee) {
		boolean result = employees.add(employee);
		return result;
	}

}
