package com.bv.main.dao;

import com.bv.main.pojo.Employee;

public interface EmployeeCRUDDAOInterface {
	public boolean addNewEmployee(Employee employee);
}
