package com.bv.main.service;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AddEmployeeResponse")
public class AddEmployeeResponse {
	private boolean result;

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}
}
