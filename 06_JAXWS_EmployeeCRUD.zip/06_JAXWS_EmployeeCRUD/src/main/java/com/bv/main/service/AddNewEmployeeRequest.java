package com.bv.main.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import com.bv.main.pojo.Employee;
@XmlType(name = "AddNewEmployeeRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class AddNewEmployeeRequest {
	private Employee employee;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	
}
