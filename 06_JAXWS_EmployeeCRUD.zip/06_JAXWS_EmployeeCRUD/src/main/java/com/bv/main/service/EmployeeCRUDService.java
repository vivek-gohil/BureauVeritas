package com.bv.main.service;

import com.bv.main.dao.EmployeeCRUDDAO;
import com.bv.main.pojo.Employee;


public class EmployeeCRUDService implements EmployeeCRUDServiceInterface {

	private EmployeeCRUDDAO employeeCRUDDAO = new EmployeeCRUDDAO();

	@Override
	public AddEmployeeResponse addEmployee(AddNewEmployeeRequest addNewEmployeeRequest) {

		Employee employee = addNewEmployeeRequest.getEmployee();

		boolean result = employeeCRUDDAO.addNewEmployee(employee);

		AddEmployeeResponse addEmployeeResponse = new AddEmployeeResponse();
		addEmployeeResponse.setResult(result);

		return addEmployeeResponse;
	}
}
