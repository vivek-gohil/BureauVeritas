package com.bv.main.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name = "employeecrud")
public interface EmployeeCRUDServiceInterface {
	@WebMethod
	public @WebResult(name = "addEmployeeResponse") AddEmployeeResponse addEmployee(
			@WebParam(name = "addNewEmployeeRequest") AddNewEmployeeRequest addNewEmployeeRequest);
}
